package com.sd.laborator

import io.micronaut.core.annotation.*

@Introspected
class HelloWorldMaven {
	lateinit var name: String
}


