package com.sd.laborator;

import com.sun.org.apache.xml.internal.security.c14n.implementations.CanonicalizerBase.XML
import io.micronaut.function.FunctionBean
import io.micronaut.function.executor.FunctionInitializer
import java.util.function.Function
import khttp.get as kget
import java.util.function.Supplier

@FunctionBean("producator-maven")
class ProducatorMavenFunction : FunctionInitializer(), Supplier<ProducatorMaven> {

    override fun get(): ProducatorMaven {
        var p = ProducatorMaven()
        val r:Response = kget("https://xkcd.com/atom.xml")
        var jsonObj = r.jsonObject
        p.continut = r.toString()
        return p
    }

}

/**
 * This main method allows running the function as a CLI application using: echo '{}' | java -jar function.jar 
 * where the argument to echo is the JSON to be parsed.
 */
fun main(args : Array<String>) { 
    val function = ProducatorMavenFunction()
    function.run(args, { context -> function.get()})
}