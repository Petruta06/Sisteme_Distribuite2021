package com.sd.laborator

import io.micronaut.core.annotation.*

@Introspected
class ProducatorMaven {
	lateinit var continut: String
}


