package com.sd.laborator.model

data class Content(var author: String?, var text: String?, var name: String?, var publisher: String?)