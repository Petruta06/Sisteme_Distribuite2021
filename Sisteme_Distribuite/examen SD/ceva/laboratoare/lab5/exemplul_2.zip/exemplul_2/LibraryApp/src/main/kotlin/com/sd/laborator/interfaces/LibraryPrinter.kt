package com.sd.laborator.interfaces

interface LibraryPrinter: HTMLPrinter, JSONPrinter, RawPrinter