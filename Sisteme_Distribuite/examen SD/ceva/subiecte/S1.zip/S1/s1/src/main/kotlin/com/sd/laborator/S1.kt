package com.sd.laborator

import io.micronaut.core.annotation.*

@Introspected
class S1 {
	lateinit var name: String
}


