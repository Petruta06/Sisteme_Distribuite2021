package com.sd.laborator

import io.micronaut.core.annotation.Introspected

@Introspected
class S1Request {


}