package com.sd.laborator.model

data class Stack(var data: MutableSet<Int>)