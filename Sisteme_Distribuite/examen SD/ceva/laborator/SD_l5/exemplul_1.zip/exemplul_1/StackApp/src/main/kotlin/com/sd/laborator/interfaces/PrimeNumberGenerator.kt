package com.sd.laborator.interfaces

interface PrimeNumberGenerator {
    fun generatePrimeNumber(): Int
}