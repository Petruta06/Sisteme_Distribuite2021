package com.sd.laborator

import org.springframework.stereotype.Service

@Service
class HelloService {
    fun getHello() = "Hello World!"
}