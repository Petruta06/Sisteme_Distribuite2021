package interfaces;

public interface StatelessSessionBeanRemote {
    String getCurrentTime();
    Integer addNumbers(Integer a, Integer b);
}